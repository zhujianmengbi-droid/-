# -*- mode: python ; coding: utf-8 -*-

import os


a = Analysis(
    ['main_large.py'],
    pathex=[],
    binaries=[],
    datas=[('app.ico', '.')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)

# Windows 自带这些 API-set / CRT 转发 DLL。避免 onefile 临时目录中的版本
# 遮蔽系统版本，保持 PySide6.QtCore 在不同 Windows 11 环境下都能启动。
a.binaries = [
    entry for entry in a.binaries
    if not os.path.basename(entry[0]).lower().startswith('api-ms-')
    and os.path.basename(entry[0]).lower() != 'ucrtbase.dll'
    and os.path.basename(entry[0]).lower() not in {
        'icuuc.dll', 'icudt78.dll', 'libcrypto-3-x64.dll', 'libssl-3-x64.dll',
    }
]

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='逐渐优化器',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['app.ico'],
)
