"""Windows 桌面合成回归：运行时短暂显示测试背景，不修改系统设置。"""
import ctypes
import time
import unittest

from PySide6.QtCore import QPoint, Qt
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import QApplication, QPushButton, QWidget
import main


class Board(QWidget):
    mode = 0

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor('white' if self.mode == 1 else 'black'))
        if self.mode == 2:
            for x in range(0, self.width(), 8):
                painter.fillRect(x, 0, 4, self.height(), QColor('white'))


class GlassTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setStyle('Fusion')
        cls.app.setStyleSheet(main.STYLE)
        cls.board = Board()
        cls.board.setWindowFlag(Qt.WindowType.FramelessWindowHint)
        cls.screen = cls.app.primaryScreen()
        cls.board.setGeometry(cls.screen.geometry())
        cls.board.show()
        cls.window = main.App()
        cls.window.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint)
        origin = cls.screen.geometry().topLeft()
        cls.window.setGeometry(origin.x() + 100, origin.y() + 40, 900, 600)
        cls.window.show()
        cls.wait()

    @classmethod
    def wait(cls):
        for _ in range(60):
            cls.app.processEvents()
            time.sleep(.025)

    @classmethod
    def tearDownClass(cls):
        cls.window.close()
        cls.board.close()
        cls.app.processEvents()

    def sample(self, mode):
        self.board.mode = mode
        self.board.update()
        self.window.raise_()
        self.wait()
        self.board.raise_()
        self.window.raise_()
        self.wait()
        image = self.screen.grabWindow(0).toImage()
        point = self.window.mapToGlobal(QPoint(200, 12)) - self.screen.geometry().topLeft()
        scale = self.window.devicePixelRatioF()
        return [image.pixelColor(round((point.x()+x)*scale), round(point.y()*scale)).red()
                for x in range(300)]

    def test_1_background_transmission(self):
        dark, light = self.sample(0), self.sample(1)
        delta = sum(light)/len(light) - sum(dark)/len(dark)
        print('Background transmission delta:', round(delta, 2))
        self.assertGreater(delta, 60)

    def test_2_blur_against_unblurred_control(self):
        blurred = self.sample(2)
        # 暂时关闭当前测试窗口的 Accent，用同一采样区做对照。
        class Accent(ctypes.Structure):
            _fields_ = [('state', ctypes.c_int), ('flags', ctypes.c_int),
                        ('color', ctypes.c_uint), ('animation', ctypes.c_int)]
        class Composition(ctypes.Structure):
            _fields_ = [('attribute', ctypes.c_int), ('data', ctypes.c_void_p),
                        ('size', ctypes.c_size_t)]
        accent = Accent(0, 0, 0, 0)
        data = Composition(19, ctypes.addressof(accent), ctypes.sizeof(accent))
        apply = ctypes.WinDLL('user32').SetWindowCompositionAttribute
        apply.argtypes = [ctypes.c_void_p, ctypes.POINTER(Composition)]
        apply(ctypes.c_void_p(int(self.window.winId())), ctypes.byref(data))
        try:
            plain = self.sample(2)
        finally:
            self.window.native_glass()
        contrast = lambda values: max(values) - min(values)
        print('Stripe contrast, blurred/plain:', contrast(blurred), contrast(plain))
        self.assertGreater(contrast(plain), 60)
        self.assertLess(contrast(blurred), contrast(plain) * .3)

    def test_3_window_controls_and_layout(self):
        original = self.window.geometry()
        self.window.toggle_maximized()
        self.wait()
        self.assertEqual(self.window.geometry(), self.window.screen().availableGeometry())
        self.window.toggle_maximized()
        self.wait()
        self.assertEqual(self.window.geometry(), original)
        self.window.showMinimized()
        self.wait()
        self.assertTrue(self.window.isMinimized())
        self.window.showNormal()
        for size in [(820, 570), (1020, 660)]:
            self.window.resize(*size)
            self.app.processEvents()
            self.assertTrue(self.window.optimize_button.isVisible())
            self.assertGreaterEqual(self.window.optimize_button.height(), 38)
        close = [b for b in self.window.findChildren(QPushButton) if b.toolTip() == '关闭']
        self.assertEqual(len(close), 1)
        self.window.set_busy(True)
        self.assertFalse(self.window.close())
        self.window.set_busy(False)

    def test_4_scan_feedback_and_idle(self):
        self.assertFalse(self.window.event_timer.isActive())
        self.window.scan()
        self.assertTrue(self.window.event_timer.isActive())
        self.assertFalse(self.window.optimize_button.isEnabled())
        deadline = time.monotonic() + 60
        while self.window.busy and time.monotonic() < deadline:
            self.app.processEvents()
            time.sleep(.02)
        self.assertFalse(self.window.busy)
        self.assertTrue(self.window.scan_ready)
        self.assertEqual(self.window.scan_completed, len(self.window.targets))
        self.assertFalse(self.window.event_timer.isActive())
        self.assertFalse(self.window.scan_progress.isVisible())
        for checkbox in self.window.checks.values():
            checkbox.setChecked(False)
        self.assertIn('0 B', self.window.junk.text())
        target = self.window.targets[0]
        self.window.checks[target.key].setChecked(True)
        self.assertIn(main.optimizer.format_bytes(target.scanned), self.window.junk.text())
        self.window.reset_selection()


if __name__ == '__main__':
    unittest.main()
