# -*- coding: utf-8 -*-
"""构建可扩展的大 GUI Windows 可执行程序。"""
import shutil
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).parent


def main():
    subprocess.run([sys.executable, str(ROOT / 'make_icon.py')], check=True, cwd=ROOT)
    for folder in (ROOT / 'build', ROOT / 'dist'):
        if folder.exists():
            shutil.rmtree(folder)
    subprocess.run([
        sys.executable, '-m', 'PyInstaller', '--noconfirm', '--clean',
        '电脑优化中心.spec',
    ], check=True, cwd=ROOT)
    print(f'构建完成：{ROOT / "dist" / "逐渐优化器.exe"}')


if __name__ == '__main__':
    main()
