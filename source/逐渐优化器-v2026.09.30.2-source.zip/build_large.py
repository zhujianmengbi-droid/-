# -*- coding: utf-8 -*-
"""构建可扩展的大 GUI Windows 可执行程序。"""
import shutil
import subprocess
import sys
import importlib
from pathlib import Path


ROOT = Path(__file__).parent


def check_build_dependencies():
    """Fail before PyInstaller when a runtime plugin was omitted from CI."""
    required = ('PySide6', 'psutil', 'uiautomation', 'comtypes')
    missing = []
    for module_name in required:
        try:
            importlib.import_module(module_name)
        except Exception as error:
            missing.append(f'{module_name} ({error})')
    if missing:
        raise RuntimeError(
            '构建依赖缺失：' + ', '.join(missing) +
            '。请先执行 python -m pip install -r requirements.txt')


def main():
    check_build_dependencies()
    subprocess.run([sys.executable, str(ROOT / 'make_icon.py')], check=True, cwd=ROOT)
    for folder in (ROOT / 'build', ROOT / 'dist'):
        if folder.exists():
            shutil.rmtree(folder)
    subprocess.run([
        sys.executable, '-m', 'PyInstaller', '--noconfirm', '--clean',
        '电脑优化中心.spec',
    ], check=True, cwd=ROOT)
    print(f'构建完成：{ROOT / "dist" / "逐渐优化器.exe"}')


if __name__ == '__main__':
    main()
