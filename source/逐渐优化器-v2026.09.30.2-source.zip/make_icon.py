# -*- coding: utf-8 -*-
"""生成电脑优化助手的纯 Python ICO 图标，无需额外图片库。"""
import math
import struct
import zlib
from pathlib import Path


def png_bytes(size: int) -> bytes:
    rows = []
    for y in range(size):
        row = bytearray([0])
        for x in range(size):
            # 深蓝圆角背景
            edge = min(x, y, size - 1 - x, size - 1 - y)
            in_round = edge >= size * 0.12 or ((x - size * .12) ** 2 + (y - size * .12) ** 2 < (size * .12) ** 2)
            if in_round:
                t = (x + y) / (2 * max(1, size - 1))
                r, g, b = int(37 - 10 * t), int(99 - 30 * t), int(235 - 30 * t)
            else:
                r, g, b = 13, 17, 23

            # 白色闪电图形，按比例绘制多边形
            sx, sy = x / size, y / size
            lightning = (
                (0.48 <= sx <= 0.66 and 0.17 <= sy <= 0.48) or
                (0.34 <= sx <= 0.57 and 0.42 <= sy <= 0.80) or
                (0.28 <= sx <= 0.73 and 0.42 <= sy <= 0.57)
            )
            # 两个尖角切除，让形状接近闪电
            if 0.45 <= sy < 0.58:
                lightning = lightning and sx > 0.34 + (sy - 0.45) * 1.2
            if 0.57 <= sy < 0.72:
                lightning = lightning and sx < 0.67 - (sy - 0.57) * 0.9
            if lightning:
                r, g, b = 255, 255, 255
            row.extend((r, g, b, 255))
        rows.append(bytes(row))
    raw = b"".join(rows)

    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)

    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0)) +
            chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def make_ico(path: Path):
    images = [(s, png_bytes(s)) for s in (16, 24, 32, 48, 64, 128, 256)]
    header = struct.pack("<HHH", 0, 1, len(images))
    directory = bytearray()
    offset = 6 + 16 * len(images)
    for size, data in images:
        directory += struct.pack("<BBBBHHII", 0 if size == 256 else size, 0 if size == 256 else size,
                                 0, 0, 1, 32, len(data), offset)
        offset += len(data)
    path.write_bytes(header + directory + b"".join(data for _, data in images))


if __name__ == "__main__":
    make_ico(Path(__file__).with_name("app.ico"))
    print("已生成 app.ico")
