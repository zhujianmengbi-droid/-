# -*- mode: python ; coding: utf-8 -*-

import os


a = Analysis(
    ['main.py'],
    pathex=[],
    binaries=[],
    datas=[('app.ico', '.')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)

# Windows 自带这些 API-set / CRT 转发 DLL。把它们塞进 onefile 的临时目录
# 会遮蔽系统版本，导致 PySide6.QtCore 在部分 Windows 11 环境中无法加载。
# 其余 Qt 运行库仍由 PyInstaller 正常收集；系统自带的 ICU/OpenSSL
# 版本由 Windows 负责解析，避免与系统中已有的 Qt 运行库混用。
a.binaries = [
    entry for entry in a.binaries
    if not os.path.basename(entry[0]).lower().startswith("api-ms-")
    and os.path.basename(entry[0]).lower() != "ucrtbase.dll"
    and os.path.basename(entry[0]).lower() not in {
        "icuuc.dll", "icudt78.dll", "libcrypto-3-x64.dll", "libssl-3-x64.dll",
    }
]

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='电脑优化助手',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['app.ico'],
)
