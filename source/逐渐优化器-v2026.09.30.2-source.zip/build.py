# -*- coding: utf-8 -*-
"""构建单文件 Windows GUI 可执行程序。"""
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent


def main():
    subprocess.run([sys.executable, str(ROOT / "make_icon.py")], check=True, cwd=ROOT)
    for folder in (ROOT / "build", ROOT / "dist"):
        if folder.exists():
            shutil.rmtree(folder)
    spec = ROOT / "电脑优化助手.spec"
    subprocess.run([
        sys.executable, "-m", "PyInstaller",
        "--noconfirm", "--clean", str(spec.name),
    ], check=True, cwd=ROOT)
    print(f"构建完成：{ROOT / 'dist' / '电脑优化助手.exe'}")


if __name__ == "__main__":
    main()
